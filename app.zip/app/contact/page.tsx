export default function ContactPage() {
  return <>
    <section className="contact-simple shell"><div><p className="eyebrow">Contact</p><h1>Every opportunity starts with a conversation.</h1><p className="lede">If you&apos;d like to connect about marketing, global business, entrepreneurship, leadership, or a future opportunity, I&apos;d be happy to hear from you.</p></div><div className="contact-card"><p className="eyebrow">Connect with Mateo</p><a href="mailto:mateosonaglia12@gmail.com"><span>Email</span><strong>mateosonaglia12@gmail.com</strong><b>↗</b></a><a href="https://www.linkedin.com/in/mateo-sonaglia-0b5757264" target="_blank" rel="noreferrer"><span>LinkedIn</span><strong>View profile</strong><b>↗</b></a><a href="tel:+19805814985"><span>Phone</span><strong>+1 980 581 4985</strong><b>↗</b></a><p>Open to meaningful conversations around marketing, global business, entrepreneurship, collaboration, and future opportunities.</p></div></section>
  </>;
}
