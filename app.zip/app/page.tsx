import Image from "next/image";
import Link from "next/link";

export default function Home() {
  return <>
    <section className="hero shell">
      <div className="hero-copy">
        <h1>Connecting markets, people, and <em>growth.</em></h1>
        <p className="hero-kicker">Global perspective. Human connection. Meaningful growth.</p>
        <p className="hero-lede">I&apos;m Mateo Sonaglia, a marketing and global business student building experience across international strategy, sales, brand growth, entrepreneurship, and community leadership. My work connects market insight, human relationships, and strategic execution to help ideas move from conversation to action.</p>
        <div className="button-row">
          <Link className="button button-primary" href="/projects">View Projects <span>→</span></Link>
          <Link className="button button-secondary" href="/resume">Resume <span>↗</span></Link>
          <Link className="button button-quiet" href="/contact">Contact</Link>
        </div>
      </div>
      <div className="hero-portrait"><div className="portrait-frame"><Image src="/images/mateo-london.jpg" alt="Professional portrait of Mateo Sonaglia" fill priority sizes="(max-width: 900px) 92vw, 38vw" /></div><div className="portrait-note"><b>Building Across Markets</b><br />Growth Through Connection</div><div className="portrait-shape" /></div>
    </section>

    <section className="section origin-story">
      <div className="shell origin-grid">
        <div><p className="eyebrow light">My story</p><h2>New environments taught me how to <em>create opportunity.</em></h2></div>
        <div className="story-copy"><p>My story includes moving from Bolivia to the United States at 18, but it has never been only about where I came from. It is about learning how to adapt, communicate across cultures, build relationships from the ground up, and create opportunities in unfamiliar environments.</p><p>That experience shaped how I approach marketing, sales, and leadership today. I listen for what connects people, recognize where an idea can create value, and help turn that connection into a project, partnership, introduction, or next step.</p><blockquote>A person&apos;s starting point should not determine how far they can go.</blockquote></div>
      </div>
    </section>

    <section className="section shell connection-section">
      <div className="section-heading"><div><p className="eyebrow">How I create value</p><h2>Growth starts with understanding people, markets, and opportunity.</h2></div></div>
      <div className="value-grid">
        <article><span>01</span><h3>Understand the context</h3><p>I bring global curiosity and careful research to understand markets, cultures, people, and the real question behind an opportunity.</p></article>
        <article><span>02</span><h3>Build genuine trust</h3><p>I listen, communicate clearly, and make people feel valued so ideas can develop into useful relationships and collaboration.</p></article>
        <article><span>03</span><h3>Create momentum</h3><p>I organize people and ideas into concrete action through strategy, content, events, partnerships, and coordinated execution.</p></article>
      </div>
    </section>

    <section className="section purpose-section"><div className="shell purpose-grid"><div><p className="eyebrow light">Purpose</p><h2>Create opportunity, then share it.</h2></div><div><p>My mission is to connect people, ideas, and opportunities and transform those connections into meaningful action. Through marketing, entrepreneurship, innovation, and global business, I want to help people and organizations recognize their potential, communicate their value, and build sustainable growth.</p><p>My long-term vision is to become a global entrepreneur and business leader who creates meaningful value, brings people together, and opens doors for others.</p><Link className="text-link light-link" href="/projects">See the work behind the story →</Link></div></div></section>

    <section className="section shell closing"><p className="eyebrow">The next connection</p><h2>Have an idea, opportunity, or project worth building?</h2><Link className="button button-accent" href="/contact">Connect with Mateo <span>→</span></Link></section>
  </>;
}
