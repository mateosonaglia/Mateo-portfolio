const experience = [
  {
    dates: "June 2026 to Present",
    org: "The Cheesecake Factory Bakery",
    role: "International Sales, Marketing & Business Development Intern",
    summary: "Supporting international sales and business development projects by coordinating with customers, external partners, and cross-functional teams across global markets.",
    points: [
      "Organize customer-facing materials, including TDS files, artwork, product imagery, samples, and updated item codes for packaging transitions and new business opportunities",
      "Assist with sales forecasting, shipment follow-ups, and project coordination to help move customer requests forward",
      "Build on the international market research, pricing, and digital strategy foundation developed during my Summer 2025 internship",
    ],
  },
  {
    dates: "September 2025 to Present",
    org: "American Marketing Association Club, California Lutheran University",
    role: "President",
    summary: "Lead a student executive team in creating professional development experiences, campus-wide programming, brand partnerships, and events that connect students with alumni, brands, and industry professionals.",
    points: [
      "Lead events, marketing initiatives, and partnerships to grow member engagement",
      "Manage brand presence and strategic programming for the organization",
      "Coordinate with the executive team to plan and execute high-impact student experiences",
    ],
  },
  {
    dates: "September 2025 to Present",
    org: "SOM-thing Local Initiative, School of Management Brand Ambassadors",
    role: "Project Leader",
    summary: "Lead a student-led initiative connecting local businesses with the university community through content strategy, storytelling, and community engagement.",
    points: [
      "Oversee brand strategy, content direction, and cross-functional team execution",
      "Drive community engagement through storytelling and event-based activation",
      "Support local brand visibility through a repeatable short-form content system",
    ],
  },
  {
    dates: "June 2025 to September 2025",
    org: "The Cheesecake Factory Bakery",
    role: "International Sales, Marketing & Business Development Intern",
    summary: "Supported international expansion efforts across Europe and Asia through market research, competitive analysis, product strategy, pricing logic, and digital positioning.",
    points: [
      "Supported international expansion through market and competitive research",
      "Contributed to pricing and portfolio strategy by product format and market",
      "Developed go-to-market and digital positioning frameworks for global markets",
    ],
  },
];

const additionalExperience = [
  {
    org: "Media 43",
    role: "Social Media Marketing Intern",
    summary: "Supported content creation, digital storytelling, and social media execution to strengthen brand visibility and audience engagement.",
  },
  {
    org: "California Lutheran University Admissions",
    role: "Undergraduate Recruitment Intern",
    summary: "Represented Cal Lutheran through student outreach, campus tours, and admissions support, helping 12+ prospective students commit to CLU.",
  },
];

const skills = [
  {title:"Strategy & Analysis", text:"Market Research · GTM Strategy · Pricing & Portfolio Strategy · Brand Positioning · Market Analysis"},
  {title:"Digital Marketing & Content", text:"Content Strategy · Social Media Strategy · Brand Storytelling · Community Engagement · Digital Campaign Planning"},
  {title:"Leadership & Project Management", text:"Project Leadership · Team Coordination · Cross-Functional Collaboration · Initiative Development · Event & Community Activation"},
  {title:"Tools & Platforms", text:"Adobe Photoshop · Adobe Premiere · Canva · Wix · Meta Business Suite · Google Workspace · Microsoft Office · Analytics Reporting"},
];

export default function ResumePage() {
  return <>
    <section className="page-hero resume-hero shell">
      <p className="eyebrow">Resume snapshot</p>
      <h1>Experience Snapshot</h1>
      <p className="resume-subtitle">Global Marketing &amp; Brand Strategy | International Sales, Campus Leadership, and Community Growth</p>
      <a className="button button-primary" href="/MateoSonagliaResume.pdf" download>Download full resume <span>↓</span></a>
    </section>

    <section className="resume-section resume-experience-section shell">
      <div className="resume-section-heading">
        <p className="eyebrow">Selected experience</p>
        <h2>Work Experience</h2>
        <p>A curated view of my most relevant international, leadership, and community-focused work.</p>
      </div>
      <div className="experience-cards">
        {experience.map((item, index) => <article className={index === 0 ? "experience-card experience-current" : "experience-card"} key={`${item.org}-${item.dates}`}>
          <div className="experience-card-top">
            <time>{item.dates}</time>
            {index === 0 && <span>Current focus</span>}
          </div>
          <p className="experience-org">{item.org}</p>
          <h3>{item.role}</h3>
          <p className="experience-summary">{item.summary}</p>
          <ul>{item.points.map((point) => <li key={point}>{point}</li>)}</ul>
        </article>)}
      </div>
    </section>

    <section className="resume-section additional-experience-section shell">
      <div className="resume-section-heading">
        <p className="eyebrow">Broader experience</p>
        <h2>Additional Experience</h2>
      </div>
      <div className="additional-experience-grid">
        {additionalExperience.map((item) => <article key={item.role}>
          <p>{item.org}</p>
          <h3>{item.role}</h3>
          <span className="additional-summary">{item.summary}</span>
        </article>)}
      </div>
    </section>

    <section className="resume-section education-section shell">
      <div className="resume-section-heading">
        <p className="eyebrow">Education</p>
        <h2>Academic Foundation</h2>
      </div>
      <div className="education-content-stack">
        <article className="education-card education-card-expanded">
          <div className="education-card-top">
            <time>January 2023 to Present · Expected Graduation December 2026</time>
            <div><span>GPA</span><strong>3.85</strong></div>
          </div>
          <p>California Lutheran University</p>
          <h3>Bachelor of Science in Business Administration</h3>
          <div className="education-detail-grid">
            <div>
              <span className="detail-label">Academic focus</span>
              <p>Emphases in Marketing and Global Business</p>
              <p>Minor in Innovation and Entrepreneurship</p>
            </div>
            <div>
              <span className="detail-label">Relevant coursework</span>
              <p>Social Media Analytics, Global Business, Marketing, and Economics courses</p>
            </div>
          </div>
          <div className="education-highlights">
            <div><span>Student Athlete</span><strong>Men&apos;s Tennis Team</strong></div>
          </div>
        </article>
        <article className="academic-experience-card eia-academic-card">
          <div>
            <p>International innovation experience</p>
            <h3>European Innovation Academy</h3>
          </div>
          <time>London · July 2026</time>
          <p>Participating in an intensive international innovation program, collaborating across cultures while applying entrepreneurship, customer discovery, and venture development.</p>
        </article>
        <article className="academic-experience-card study-abroad-card">
          <div>
            <p>Independent international experience</p>
            <h3>Study Abroad · Magdeburg, Germany</h3>
          </div>
          <time>March 2022 to December 2022</time>
          <p>Completed an external study abroad experience before enrolling at Cal Lutheran, strengthening cross-cultural adaptability and global perspective.</p>
        </article>
      </div>
    </section>

    <section className="resume-section skills-section shell">
      <div className="resume-section-heading">
        <p className="eyebrow">Capabilities</p>
        <h2>Skills &amp; Expertise</h2>
      </div>
      <div className="skill-groups">
        {skills.map((skill, index) => <article className={`skill-card skill-card-${index + 1}`} key={skill.title}>
          <span>0{index + 1}</span>
          <h3>{skill.title}</h3>
          <p>{skill.text}</p>
        </article>)}
      </div>
    </section>
  </>;
}
